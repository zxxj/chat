export interface Tabs {
  path: string
  tabName: string
}
