const ContentComponent: React.FC = () => {
  return <div>123</div>
}

export default ContentComponent
